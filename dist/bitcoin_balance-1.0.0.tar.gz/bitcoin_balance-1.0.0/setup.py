import setuptools

setuptools.setup(
    name = "bitcoin_balance",
    version = "1.0.0",
    author = "Aridai Bordón",
    description = "Check the balance of any bitcoin address"
)